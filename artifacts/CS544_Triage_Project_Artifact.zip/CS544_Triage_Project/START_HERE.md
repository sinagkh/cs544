# Selective LLM issue triage group artifact

Prepared for the CS544 group on October 21, 2026.

## Start with the documents

- [Full project report](paper/main.pdf) and editable LaTeX sources in `paper/`.
- [Two-page proposal PDF](documents/Two_Page_Project_Proposal.pdf).
- [Editable two-page proposal](documents/Two_Page_Project_Proposal.docx), including 10 linked papers and all three group members.
- [Results and tables](report/results.md), figures, supporting analyses, and human-audit sheets in `report/`.
- [Project README](README.md) for the system design and the full experiment commands.

## Current status and next work

The full report contains the current Qwen2.5-7B and classical-classifier measurements. The two-page proposal includes planned methodological validation. Existing numerical results describe the current implementation; those validation changes remain to be completed.

Before final submission, separate temperature fitting from statistical certification, use source-only calibration for held-out repositories, complete the human rewrite audit, and add controls for the newcomer sentence's question-like wording. Include changes in human-review workload in the fairness analysis and evaluate false alarms on independent clean traffic. Small selected subsets need uncertainty intervals.

## What is included

The current source code, scripts, dependency declarations, tests, prepared evaluation data, recorded predictions, response caches, paper sources, full report PDF, and two-page proposal are included. SQLite files were copied through database backups to make coherent snapshots.

## What was left out

- `.venv/`, Python bytecode, installed-package metadata, test caches, and execution logs.
- Downloaded model weights and external Hugging Face caches. The prepared data, public raw issue snapshot, embeddings, predictions, explanations, and response cache are included.

The Python environment accounted for about 1.3 GB in the original folder. Recreate it locally. Model weights are downloaded separately when running live inference.

## Use the packaged results

Reading the reports requires a PDF reader or Word-compatible editor. Running the original full setup and live inference uses Apple silicon through MLX. From this extracted project folder:

```bash
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python -e .
.venv/bin/python -I -m pytest -q
.venv/bin/python -I -m pytest -q -m replay
.venv/bin/python -I scripts/analyze.py --out report_recomputed
```

The analysis command recomputes tables and figures from saved predictions in a separate output folder. Replay tests use recorded responses; tokenizer assets may download on the first run. See `VALIDATION.md` for the handoff checks.

The original README also lists dataset rebuilding and live-inference commands. The prepared data in this archive are the snapshot associated with the supplied reports. Keep that snapshot available when comparing new results.

## Data sources

The benchmark comes from the [NLBSE 2024 issue classification repository](https://github.com/nlbse2024/issue-report-classification). `data/raw/nlbse24/` retains the source files and the supplied license file. The recent issues were collected from the public GitHub repositories listed in `README.md`; their snapshot and label mapping are included. Re-fetching GitHub issues produces a newer snapshot. Use the packaged snapshot when checking the reported numbers.

## Integrity and future GitHub sharing

`SHA256SUMS.txt` lists the packaged files and their hashes. The outer ZIP also has a sidecar SHA-256 checksum. A future GitHub repository can track source, documentation, and reports while distributing this reproducibility snapshot as a release asset. Each teammate should create their own `.venv/`.
