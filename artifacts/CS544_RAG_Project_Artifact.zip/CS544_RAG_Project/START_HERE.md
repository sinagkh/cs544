# RAG diagnosis and repair group artifact

Prepared for the CS544 group on October 21, 2026.

## Start with the documents

- [Full project report](paper/main.pdf) and editable LaTeX sources in `paper/`.
- [Two-page proposal PDF](documents/Two_Page_Project_Proposal.pdf).
- [Editable two-page proposal](documents/Two_Page_Project_Proposal.docx), including 10 linked papers and all three group members.
- [Results and tables](report/results.md), figures, supporting analyses, and human-audit sheets in `report/`.
- [Project README](README.md) for the system design and the full experiment commands.

## Current status and next work

The full report contains the current Llama-3.2-3B measurements. The two-page proposal describes the study and planned validation. The Qwen run in `results/pending/` is incomplete. Trace checks encode predefined fault families and repair rules.

Before final submission, complete the independent human answer audit in `report/audit/`, validate the missing-evidence cases, and evaluate monitoring false alarms on independent clean traffic. A second completed generator run would broaden the evidence.

## What is included

The current source code, scripts, dependency declarations, tests, prepared evaluation data, recorded predictions, response caches, paper sources, full report PDF, and two-page proposal are included. SQLite files were copied through database backups to make coherent snapshots.

## What was left out

- `.venv/`, Python bytecode, installed-package metadata, test caches, and execution logs.
- The original HotpotQA parquet download in `data/raw/`; the built evaluation snapshot is included. The original README gives its download command.
- `data/corpus_emb.npy`, an intermediate already represented by the corpus rows in `data/embeddings.npz`. See the restoration command below if rerunning only `scripts/embed_store.py`.
- Earlier prototype code and results. `archive/v1/dataset.json` is retained because `scripts/build_dataset.py` reads its development/test IDs to reproduce exclusion choices.

The Python environment accounted for about 1.3 GB in the original folder. Recreate it locally. Model weights are downloaded separately when running live inference.

## Use the packaged results

Reading the reports requires a PDF reader or Word-compatible editor. Running the original full setup and live inference uses Apple silicon through MLX. From this extracted project folder:

```bash
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python -e .
.venv/bin/python -I -m pytest -q
.venv/bin/python -I -m pytest -q -m replay
.venv/bin/python -I scripts/analyze.py results/Llama-3.2-3B-Instruct-4bit_test.jsonl --out report_recomputed
```

The analysis command recomputes tables and figures from saved predictions in a separate output folder. Replay tests use recorded responses; tokenizer assets may download on the first run. See `VALIDATION.md` for the handoff checks.

The original README also lists dataset rebuilding and live-inference commands. The prepared data in this archive are the snapshot associated with the supplied reports. Keep that snapshot available when comparing new results.

## Restore the optional corpus embedding intermediate

The packaged index already supports the current pipeline and replay tests. To recreate the intermediate used by `scripts/embed_store.py`, run from the project root after setup:

```bash
.venv/bin/python -I -c "import json,numpy as np; d=json.load(open('data/dataset.json')); z=np.load('data/embeddings.npz'); np.save('data/corpus_emb.npy',z['E'][:len(d['corpus'])])"
```

## Data sources

The built corpus and questions derive from [HotpotQA](https://hotpotqa.github.io/) and its [Hugging Face dataset](https://huggingface.co/datasets/hotpotqa/hotpot_qa). Synthetic outdated passages, predictions, judge outputs, and audit sheets are included for this class project. Consult the upstream sources for dataset terms and attribution.

## Integrity and future GitHub sharing

`SHA256SUMS.txt` lists the packaged files and their hashes. The outer ZIP also has a sidecar SHA-256 checksum. A future GitHub repository can track source, documentation, and reports while distributing this reproducibility snapshot as a release asset. Each teammate should create their own `.venv/`.
